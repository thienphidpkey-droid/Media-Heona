# AI Context

## Overview
This file provides context for AI assistants working on this project.

## Technology Stack
- React
- TypeScript
- Vite
- Tailwind CSS

## Project Structure
- `/components`: Reusable UI components
- `/pages`: Application pages
- `/context`: React contexts

## Guidelines
- Follow standard TypeScript and React best practices.
- Ensure responsive design using Tailwind CSS.
